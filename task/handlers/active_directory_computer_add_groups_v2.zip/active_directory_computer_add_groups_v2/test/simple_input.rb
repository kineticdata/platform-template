{
  'info' => {
    'host' => "",
    'username' => "",
    'password' => "",
    'port' => "389",
    'base' => "",
    'enable_debug_logging' => "Yes"
  },
  'parameters' => {
    'search_by' => 'Computer Name',
    'search_value' => 'Test Computer',
    'groups' => 'TestComputerGroup'
  }
}

